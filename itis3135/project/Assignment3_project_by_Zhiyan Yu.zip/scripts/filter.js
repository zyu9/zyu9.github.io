$(function($) {
    $.autofilter({
        // filter string as substring
        subString: false,

        // is case sensitive?
        caseSensitive: false,

        // enable animation
        animation: true,

        // duration in ms
        duration: 0
    });
  });